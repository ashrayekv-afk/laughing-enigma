/* Bounded browser-only extraction scheduling. No clinical data is persisted. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.NKPIExtractionFlow=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const jobs=new WeakMap(),reads=new WeakMap(),epochs=new WeakMap();
function cancelled(){const e=new Error('Source changed. The obsolete extraction was discarded.');e.code='cancelled';return e;}
function check(current){if(!current())throw cancelled();}
async function exclusive(worker,epoch,current,fn){
 if(!worker){check(current);return fn(null);}
 const previous=jobs.get(worker)||Promise.resolve();let release;
 const held=new Promise(resolve=>{release=resolve;});
 const tail=previous.catch(()=>{}).then(()=>held);jobs.set(worker,tail);
 await previous.catch(()=>{});
 try{check(current);epochs.set(worker,epoch);const value=await fn(worker);check(current);return value;}
 finally{epochs.delete(worker);release();if(jobs.get(worker)===tail)jobs.delete(worker);}
}
async function atomic(worker,current,fn){
 const previous=reads.get(worker)||Promise.resolve();
 const task=previous.catch(()=>{}).then(async()=>{check(current);const value=await fn();check(current);return value;});
 reads.set(worker,task);try{return await task;}finally{if(reads.get(worker)===task)reads.delete(worker);}
}
async function map(items,workers,epoch,current,fn){
 const output=new Array(items.length),pool=workers?.length?workers.slice(0,2):[null];
 let next=0,failed=null;
 const lanes=pool.slice(0,Math.max(1,Math.min(pool.length,items.length))).map(async worker=>{
  while(next<items.length&&!failed){check(current);const i=next++;
   try{output[i]=await exclusive(worker,epoch,current,w=>fn(items[i],w,i));}
   catch(e){failed=e;throw e;}
  }
 });
 // Drain every active lane before returning, even when a sibling fails.
 const settled=await Promise.allSettled(lanes);const error=settled.find(r=>r.status==='rejected');
 if(error)throw error.reason;check(current);return output;
}
class BitmapCache{
 constructor(limit=48*1024*1024){this.limit=limit;this.entries=new Map();this.pending=new Map();this.bytes=0;this.generation=0;this.hits=0;}
 clear(){this.generation++;this.entries.clear();this.pending.clear();this.bytes=0;this.hits=0;}
 async get(key,loader){
  if(this.entries.has(key)){const entry=this.entries.get(key);this.entries.delete(key);this.entries.set(key,entry);this.hits++;return entry.value;}
  if(this.pending.has(key)){this.hits++;return this.pending.get(key);}
  const generation=this.generation;
  const task=Promise.resolve().then(loader).then(value=>{
   if(generation!==this.generation)return value;
   const bytes=Number(value.width)*Number(value.height)*4;
   if(Number.isFinite(bytes)&&bytes>0&&bytes<=this.limit){
    while(this.bytes+bytes>this.limit&&this.entries.size){const oldest=this.entries.keys().next().value;this.bytes-=this.entries.get(oldest).bytes;this.entries.delete(oldest);}
    this.entries.set(key,{value,bytes});this.bytes+=bytes;
   }
   return value;
  }).finally(()=>{if(this.pending.get(key)===task)this.pending.delete(key);});
  this.pending.set(key,task);return task;
 }
}
return Object.freeze({map,exclusive,atomic,workerEpoch:w=>epochs.get(w),cancelled,check,BitmapCache});
});
