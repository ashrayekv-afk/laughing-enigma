# Component loading repair — 9.1.5-loading-fix-1

Source: the deployed v9.1.5 runtime, SHA-256
`b058e8cf6f032939f6a2fa1f3e0aff5333e03f1bda286c49a25bb4dfcde57975`.
The source archive recovered from Library matches the hash in the current GitHub launcher.

## What was changed

- Registration moved to importable `nkpi.component`, rather than depending on the
  transient `__main__` namespace used by `runpy`.
- An absolute component directory is used. The hash-checked, atomic runtime extraction
  is retained; a temporary directory itself was not established to be the cause.
- The 21 top-level CSS/JavaScript dependencies are inlined into the component HTML.
  The main interface therefore does not require 21 separate browser asset responses.
  The extractor still has its own local assets. Its code and all vendor files are unchanged.
- A dependency-free handshake runs first, buffers an early model/config response,
  and replays it after application initialization. Failures show recovery instructions.
- A native Streamlit basic calculator is accessible before the custom component.
  It uses the same backend, supports one/two visits and OD/OS, and requires source
  confirmation. Blank fields are not filled with fabricated inputs. Editing invalidates
  old results. It has no image/ZIP uploader or 3D view; those remain in Full interface.
- Component name/key and UI version changed to avoid reusing the older frontend instance.
- No model parameters, geometry, extraction rules, thresholds or interpretation were changed.

## Completed checks

- 41 retained Python tests passed.
- 58 Node test-runner tests passed across the retained JavaScript suite.
- 10 new recovery-control/adapter tests passed using a Streamlit API stub.
- 17 real-Chromium checks passed using an offline HTML harness with simulated Streamlit
  parent messaging. Checks covered ready/config handshake, delayed startup, early render
  replay, both-eye baseline/two-visit scoring, browser audit, stale-result invalidation,
  next-patient reset and actionable startup-error reporting.
- 48 synthetic complete assessment outputs were identical to the deployed source,
  excluding only the UI-version string. These are engineering regression cases.
- Model/research artifacts, all corneal viewer modules and all extractor files were
  preserved byte-for-byte. Python/JS syntax, archive CRC, manifest, and launcher checks
  are recorded in the supplied package verification workflow.

## Limitations

The screenshot alone does not identify the original network or browser failure.
The full-interface loading failure was not reproduced on the live clinic deployment.
These checks are NOT a live Streamlit Cloud/hospital-network test. Streamlit was not
available in this build environment; parent transport was simulated and native UI calls
were tested with an API stub. The browser extractor was an inert test fixture: no new
end-to-end OCR test was performed, and no patient files were used. Corneal viewer
initialization was checked, but its measurement/anatomical validity was not revalidated.
This patch does not make a research index clinically validated or privacy-approved.

## Maintenance

Run `python tools/build_component.py` after changing a top-level component JS/CSS file.
Rebuild the manifest and runtime ZIP and update the launcher's SHA-256 before distributing.

Streamlit primary documentation consulted:
- https://docs.streamlit.io/develop/api-reference/custom-components/st.components.v1.declare_component
- https://docs.streamlit.io/develop/concepts/custom-components/components-v1/intro
