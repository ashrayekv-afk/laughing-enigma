'use strict';
// Engineering fixtures; these assertions do not establish clinical accuracy.
const assert=require('node:assert/strict');
const M=require('../components/cornea/integrated_model.js');
const S=require('../components/cornea/patient_shape.js');
let count=0;
const test=(name,fn)=>{fn();count++;console.log('PASS '+name);};
const close=(a,b)=>assert(Math.abs(a-b)<1e-8,`${a} != ${b}`);
function grid(n,diameter,extent,fn){const c=(n-1)/2,step=diameter*extent/(n-1);return Array.from({length:n},(_,j)=>Array.from({length:n},(_,i)=>{
 if(Math.hypot(i-c,j-c)>c+1e-8)return null;const value=fn((i-c)*step,(c-j)*step);
 return value===null?null:{value,lo:value-1,hi:value+1};
}));}
function display(diameter,key,fn){const g=grid(61,diameter,1,fn),c=30,total=g.flat().filter((_,i)=>Math.hypot(i%61-c,Math.floor(i/61)-c)<=c+1e-8).length;
 return {schema:'nkpi-report-display-grid-1',extent:1,diameter_mm:diameter,[key]:g,coverage:g.flat().filter(Boolean).length/total};}
function fixture(e=(x,y)=>20+3*x+2*y){
 const d=9,shape={schema:'nkpi-image-shape-1',source:'report_elevation_estimate',reference:'centered_untilted_float_bfs',bfs_radius_mm:7.8,fit_diameter_mm:8,diameter_mm:d,extent:2/3,elevation_um:grid(41,d,2/3,e),legend_step_um:5,
  legend_provenance:{anchors:[-100,-50,0,50,100].map(value=>({value})),calibrated_range_um:[-100,100]},full_display:display(d,'elevation_um',e)};
 const map=(id,fn,limits)=>({schema:'nkpi-report-image-map-1',id,unit:id==='thickness'?'µm':'D',map_type:id==='thickness'?'pachymetry':'axial',source:'report_color_estimate',diameter_mm:d,registration:'printed_plot_circle',extent:2/3,
  grid:grid(41,d,2/3,fn),full_display:display(d,'grid',fn),legend:{anchors:limits.map(value=>({value}))}});
 return {eye:'OD',visit:'latest',shape_estimate:shape,image_maps:[map('thickness',(x,y)=>500+10*x+5*y,[300,500,700,900]),map('anterior',(x,y)=>45+x+.5*y,[20,40,60,80]),map('posterior',(x,y)=>8+.1*x,[2,4,8,12])]};
}
function posterior(f,fn=(x,y)=>-15+4*x-y){const d=9;return {schema:'nkpi-image-elevation-map-1',surface:'posterior',source:'report_elevation_estimate',reference:'independent_posterior_float_bfs',unit:'um',bfs_radius_mm:6.5,fit_diameter_mm:8,diameter_mm:d,extent:2/3,
 elevation_um:grid(41,d,2/3,fn),full_display:display(d,'elevation_um',fn),legend_step_um:5,legend_provenance:structuredClone(f.shape_estimate.legend_provenance)};}

test('Generic report calibration shapes the same physical field without changing the source',()=>{
 const f=fixture(),before=JSON.stringify(f),m=M.fromReport(f),v=m.vertices[30*61+55];
 assert.equal(m.kind,'estimated');assert.equal(m.sourceKind,'report-image');assert.equal(m.radius,4.5);assert.equal(m.nx,61);
 close(v.front[0],3.75);close(v.front[2],Math.sqrt(7.8**2-3.75**2)-7.8+(20+3*3.75)/1000);close(v.thickness,537.5);
 assert.equal(JSON.stringify(f),before);assert.deepEqual(m.availableFields,['thickness','anterior','posterior','elevation']);
});
test('A known clipped front sample stays unavailable after nearby local fitting',()=>{
 const f=fixture();f.shape_estimate.full_display.elevation_um[30][30]={value:99,lo:98,hi:100};
 const m=M.fromReport(f),index=30*61+30;
 assert.equal(m.vertices[index],null);assert(m.triangles.every(t=>!t.includes(index)));assert(m.endpointCensoring.censoredGeometry>0);
});
test('A known clipped thickness sample cannot become an invented inner boundary',()=>{
 const f=fixture();f.image_maps[0].full_display.grid[30][30]={value:301,lo:300,hi:302};
 const m=M.fromReport(f),v=m.vertices[30*61+30];assert(v);assert.equal(v.thickness,null);assert.equal(v.back,null);
});
test('Partial patch view retains the global rejection and only local-supported source cells',()=>{
 const f=fixture((x,y)=>x<.75?100:20+x+y),m=M.fromReport(f);
 assert.equal(m.kind,'estimated');assert.equal(m.partial,true);assert(m.rejectedCompleteReason);assert(m.sourceLabel.startsWith('Partial'));
 assert(m.vertices.filter(Boolean).length>0);assert(m.vertices.filter(Boolean).every(v=>v.front[0]>=.75-1e-8));
 assert(m.triangles.every(ids=>ids.every(k=>m.vertices[k])));assert.equal(m.radius,4.5);
});
test('A central fallback retains its six-millimetre field rather than being stretched',()=>{
 const f=fixture();f.shape_estimate.full_display=display(9,'elevation_um',(x,y)=>Math.hypot(x,y)<.6?30:null);
 const m=M.fromReport(f);assert.equal(m.nx,41);assert.equal(m.radius,3);assert.equal(m.fullDisplayUsed,false);close(m.axisX[1]-m.axisX[0],.15);
});
test('Pachymetry offsets the inner boundary along a normal and not only in z',()=>{
 const m=M.fromReport(fixture()),v=m.vertices[30*61+50];
 close(Math.hypot(...v.front.map((x,k)=>x-v.back[k]))*1000,v.thickness);assert(Math.abs(v.front[0]-v.back[0])>.01);
 assert.equal(m.innerBoundaryKind,'thickness-derived');
});
test('Sparse posterior elevation remains a separately referenced point attribute',()=>{
 const f=fixture(),before=M.fromReport(f);f.shape_estimate.posterior_elevation=posterior(f,(x,y)=>x>2?10:100);
 const m=M.fromReport(f),available=m.vertices.filter(v=>Number.isFinite(v?.posterior_elevation));
 assert(available.length>0&&available.length<m.vertices.filter(Boolean).length);assert(m.mapDefinitions.posterior_elevation.partial);
 assert.deepEqual(m.vertices.map(v=>v&&[v.front,v.back,v.thickness]),before.vertices.map(v=>v&&[v.front,v.back,v.thickness]));
 assert.equal(m.mapDefinitions.posterior_elevation.reference,'independent_posterior_float_bfs');
});
test('Unknown elevation calibration supplies reference anatomy without a fabricated cone',()=>{
 const f=fixture();delete f.shape_estimate.legend_provenance;const m=M.fromReport(f);
 assert.equal(m.kind,'reference');assert.equal(m.hasPatientGeometry,false);assert.match(m.referenceReason,/calibration/);
 assert(m.vertices.every(v=>!v||v.elevation===null));
});
test('Missing thickness leaves a front surface with no invented back coordinates',()=>{
 const f=fixture();f.image_maps=f.image_maps.filter(m=>m.id!=='thickness');const m=M.fromReport(f);
 assert.equal(m.kind,'estimated');assert.equal(m.innerBoundaryKind,'unavailable');assert(m.vertices.every(v=>!v||v.back===null));
});
test('Ambiguous image fields remain unavailable while unambiguous front geometry remains usable',()=>{
 const f=fixture();f.image_maps.push(structuredClone(f.image_maps[0]));const m=M.fromReport(f);
 assert.equal(m.kind,'estimated');assert(!m.availableFields.includes('thickness'));assert(m.sourceNotes.some(x=>/Multiple thickness/.test(x)));
});
test('Native surface coordinates and independent device pachymetry remain exact',()=>{
 const axis=[-1,0,1],make=fn=>axis.map(y=>axis.map(x=>fn(x,y))),surface={schema:'nkpi-corneal-surface-1',kind:'measured',source:'device_numeric_export',eye:'OD',visit:'latest',
  units:{xy:'mm',z:'mm',elevation:'um',thickness:'um',curvature:'D'},coordinate_system:{origin:'corneal_vertex',x_positive:'nasal',y_positive:'superior',z_positive:'anterior'},x_mm:axis,y_mm:axis,
  anterior:{z_mm:make((x,y)=>-.1*(x*x+y*y)),curvature_D:make(()=>48),curvature_type:'axial'},posterior:{z_mm:make((x,y)=>-.1*(x*x+y*y)-.6)},thickness_um:make(()=>470),thickness_definition:'device_pachymetry'};
 const f={eye:'OD',visit:'latest',surface},before=JSON.stringify(f),expected=S.fromReport(f),m=M.fromReport(f);
 assert.equal(m.kind,'native');assert.equal(m.sourceKind,'native');assert.equal(m.innerBoundaryKind,'native');
 assert.deepEqual(m.vertices,expected.vertices);assert.equal(JSON.stringify(f),before);
 const v=m.vertices[4];close(v.front[2]-v.back[2],.6);assert.equal(v.thickness,470);
 assert.throws(()=>M.fromReport({...f,eye:'OS'}),/matching/i);
});
test('Censored display metadata is recomputed from final supported vertices',()=>{
 const f=fixture();f.image_maps[0].full_display.grid[30][30]={value:301,lo:300,hi:302};const m=M.fromReport(f);
 const overlay=m.overlays.find(o=>o.id==='thickness'),n=m.vertices.filter(v=>Number.isFinite(v?.thickness)).length;
 close(overlay.coverage,n/m.vertices.filter(Boolean).length);assert.equal(m.fieldSummary.thickness.count,n);
});
console.log(`${count} integrated-model checks passed.`);
