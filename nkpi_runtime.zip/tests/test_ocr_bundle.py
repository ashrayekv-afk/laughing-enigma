"""OCR startup packaging checks, not clinical OCR accuracy validation."""
from pathlib import Path
import hashlib,base64,re
ROOT=Path(__file__).resolve().parents[1]

def test_importer_has_inline_libraries_and_no_script_requests():
    text=(ROOT/'components/extractor/index.html').read_text()
    assert not re.search(r'<script[^>]+\bsrc=',text)
    assert 'data-nkpi-source="vendor/tesseract-v7/tesseract.min.js"' in text
    assert 'data-nkpi-source="vendor/jszip-3.10.1.min.js"' in text

def test_every_inline_script_has_exact_csp_hash():
    text=(ROOT/'components/extractor/index.html').read_text()
    bodies=re.findall(r'<script[^>]*>(.*?)</script>',text,re.S)
    assert len(bodies)==23
    for body in bodies:
        token="'sha256-"+base64.b64encode(hashlib.sha256(body.encode()).digest()).decode()+"'"
        assert token in text[:10000]
    policy=re.search(r'script-src (.*?);',text,re.S).group(1)
    assert "'unsafe-inline'" not in policy

def test_scripts_follow_dom_in_preserved_order():
    text=(ROOT/'components/extractor/index.html').read_text()
    assert text.index('id="processButton"') < text.index('data-nkpi-source="vendor/jszip')
    names=['vendor/tesseract-v7/tesseract.min.js','ocr_runtime.js','app.js?v=7.9.0','second_reader.js?v=7.9.0']
    indices=[text.index('data-nkpi-source="'+n+'"') for n in names]
    assert indices==sorted(indices)

def test_required_local_ocr_files_exist():
    ex=ROOT/'components/extractor'
    for relative in ['vendor/tesseract-v7/worker.min.js','vendor/tesseract-v7/tesseract-core-lstm.wasm.js','vendor/tesseract-v7/tesseract-core-simd-lstm.wasm.js','vendor/tesseract-v7/tesseract-core-relaxedsimd-lstm.wasm.js','ocr_data/eng.traineddata','ocr_second/eng.traineddata']:
        assert (ex/relative).stat().st_size>1000

def test_self_check_contains_no_patient_data_source():
    source=(ROOT/'components/extractor/ocr_runtime.js').read_text()
    check=source[source.index('async function selfCheck'):]
    assert "fillText('12345'" in check
    assert '.files[' not in check
    assert 'fetch(' not in check

def test_cache_busting_identity_and_fallback():
    assert 'nkpi_bilateral_v915_3_extraction_upgrade' in (ROOT/'nkpi/component.py').read_text()
    assert 'Basic calculator (loading recovery)' in (ROOT/'kcn_dual_calculator_app.py').read_text()
