'use strict';
const assert=require('node:assert/strict');
const flow=require('../components/extractor/extraction_flow.js');
const wait=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
 const workers=[{id:0},{id:1}],seen=new Set();let active=0,peak=0,current=true;
 const result=await flow.map([0,1,2,3],workers,9,()=>current,async(value,worker)=>{
  assert(!seen.has(worker),'No worker is shared by two studies');seen.add(worker);active++;peak=Math.max(peak,active);
  assert.equal(flow.workerEpoch(worker),9);await wait(10+value*2);active--;seen.delete(worker);return value*2;
 });
 assert.deepEqual(result,[0,2,4,6]);assert.equal(peak,2);assert.equal(active,0);
 let params='',out=[];const worker={};
 await Promise.all(['OD','OS'].map(value=>flow.atomic(worker,()=>true,async()=>{params=value;await wait(4);out.push(params);})));assert.deepEqual(out,['OD','OS']);
 const a=flow.exclusive(worker,1,()=>true,async()=>{await wait(8);return 1;});
 const b=flow.exclusive(worker,2,()=>true,async()=>{assert.equal(flow.workerEpoch(worker),2);return 2;});
 assert.deepEqual(await Promise.all([a,b]),[1,2]);
 let published=0;
 const cancel=flow.map([1,2,3,4],workers,1,()=>current,async()=>{await wait(8);flow.check(()=>current);published++;});
 await wait(2);current=false;await assert.rejects(cancel,e=>e.code==='cancelled');assert.equal(published,0);
 let finished=false;
 await assert.rejects(flow.map([0,1],workers,1,()=>true,async v=>{if(!v)throw Error('broken');await wait(5);finished=true;}));assert(finished,'Failed batches drain their active sibling lane');
 const cache=new flow.BitmapCache(100);let loads=0;const key={};
 const loader=async()=>{loads++;await wait(3);return {width:4,height:4};};
 const [c,d]=await Promise.all([cache.get(key,loader),cache.get(key,loader)]);assert.equal(c,d);assert.equal(loads,1);await cache.get(key,loader);assert.equal(loads,1);
 await cache.get({},loader);assert(cache.bytes<=100);cache.clear();assert.equal(cache.bytes,0);await cache.get(key,loader);assert.equal(loads,3);
 let done;const delayed=new Promise(r=>done=r);const pending=cache.get({},()=>delayed);cache.clear();done({width:3,height:3});await pending;assert.equal(cache.bytes,0,'Old import cannot repopulate decoded cache');
 console.log('PASS bounded two-worker parallelism, ordered outputs, exclusive leases, atomic parameters, cancellation, failure draining, bounded image reuse and generation clearing.');
})().catch(e=>{console.error(e);process.exitCode=1;});
