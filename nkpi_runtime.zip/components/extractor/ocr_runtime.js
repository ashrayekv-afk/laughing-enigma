/* NKPI 9.1.5.2: self-hosted OCR startup, recovery, and synthetic self-check.
 * No patient input, filenames, source pixels, or raw error details are logged.
 */
'use strict';
window.NKPIOCR = (() => {
  const VERSION = '9.1.5.3-extraction-upgrade';
  const BASE = new URL('.', document.baseURI);
  let libraryPromise = null;
  let checking = false;
  const local = (relative) => new URL(relative, BASE).href;
  const libraryReady = () => typeof window.Tesseract?.createWorker === 'function';
  function status(message, kind = 'info') {
    const target = document.getElementById('ocr-runtime-status');
    if (target) { target.textContent = message; target.dataset.state = kind; }
  }
  function fail(code, message) {
    const error = new Error(`${message} [${code}; ${VERSION}]`);
    error.code = code;
    return error;
  }
  async function ensureLibrary() {
    if (libraryReady()) return window.Tesseract;
    if (libraryPromise) return libraryPromise;
    // Normally unnecessary: this library is inline in the importer HTML. This is
    // a same-origin recovery route, never a public CDN or patient-file upload.
    libraryPromise = new Promise((resolve, reject) => {
      const script = document.createElement('script');
      let timer;
      function done(error) {
        clearTimeout(timer); script.onload = null; script.onerror = null;
        if (error) { script.remove(); reject(error); } else resolve(window.Tesseract);
      }
      script.src = local('vendor/tesseract-v7/tesseract.min.js') + '?release=' + VERSION;
      script.onload = () => done(libraryReady() ? null : fail('OCR-LIB-INIT', 'The local OCR library could not initialize.'));
      script.onerror = () => done(fail('OCR-LIB-LOAD', 'The browser could not load the local OCR library.'));
      timer = setTimeout(() => done(fail('OCR-LIB-TIMEOUT', 'The local OCR library request timed out.')), 20000);
      document.head.appendChild(script);
    }).finally(() => { libraryPromise = null; });
    return libraryPromise;
  }
  async function createWorker(kind = 'primary', logger = () => {}) {
    const api = await ensureLibrary();
    if (typeof Worker !== 'function' || typeof WebAssembly !== 'object') {
      throw fail('OCR-BROWSER', 'This browser does not allow the Web Worker or WebAssembly features required for OCR. Use the Basic calculator with verified measurements.');
    }
    if (!['primary','secondary'].includes(kind)) throw new TypeError('Unknown OCR model');
    const options = {
      workerPath: local('vendor/tesseract-v7/worker.min.js'),
      // Keep the same primary core feature detection and the portable secondary
      // core used by the existing release. Recognition weights are unchanged.
      corePath: local(kind === 'secondary' ? 'vendor/tesseract-v7/tesseract-core-lstm.wasm.js' : 'vendor/tesseract-v7/'),
      langPath: local(kind === 'secondary' ? 'ocr_second' : 'ocr_data/'),
      gzip: false, cacheMethod: 'write',
      cachePath: kind === 'secondary' ? 'nkpi-eng-best-8280aed0782fe27257a6' : 'nkpi-eng-fast-7d4322bd2a7749724879',
      logger,
    };
    // Direct same-origin workers do not need blob-worker permission. An opaque
    // embedded origin must use the library's standard blob-import transport.
    const direct = location.origin === new URL(options.workerPath).origin;
    try {
      return await startCached(api, {...options, workerBlobURL: !direct});
    } catch (error) {
      // A sandbox may disallow direct workers despite a matching displayed
      // origin. Retry once with the library's standard same-origin blob import.
      if (direct && error?.code === 'OCR-WORKER') {
        return await startCached(api, {...options, workerBlobURL: true});
      }
      throw error;
    }
  }
  async function startCached(api, options) {
    try {return await start(api,options);}
    catch(error) {
      if(error?.code!=='OCR-ASSET' || options.cacheMethod==='none') throw error;
      // Blocked/private storage is optional; recognition never requires it.
      return start(api,{...options,cacheMethod:'none'});
    }
  }
  async function start(api, options) {
    let timer, expired = false, rejectStartup, pending;
    const failed = new Promise((_, reject) => { rejectStartup = reject; });
    // Tesseract 7 can leave createWorker pending after a language-data error.
    // Reject explicitly instead of leaving the extraction button spinning.
    options.errorHandler = () => rejectStartup(fail('OCR-ASSET', 'A bundled OCR worker, engine, or English model could not load. Retry the self-check; if it persists, use the Basic calculator and check app/network access.'));
    try {
      pending = api.createWorker('eng', api.OEM.LSTM_ONLY, options);
      const timeout = new Promise((_, reject) => {
        timer = setTimeout(() => {
          expired = true;
          reject(fail('OCR-TIMEOUT', 'OCR initialization timed out. Reload the page and run the OCR self-check.'));
        }, 75000);
      });
      pending.then((worker) => { if (expired) worker.terminate(); }).catch(() => {});
      const worker = await Promise.race([pending, failed, timeout]);
      return worker;
    } catch (error) {
      expired = true;
      if ((typeof error?.code === 'string' && error.code.startsWith('OCR-'))) throw error;
      throw fail('OCR-WORKER', 'The browser could not start the local OCR worker. Reload and run the OCR self-check; browser or network restrictions may require the Basic calculator.');
    } finally { clearTimeout(timer); }
  }
  async function selfCheck() {
    if (checking) return;
    if (document.getElementById('processButton')?.disabled || window.nkpiMapsRunning?.()) {
      status('Finish the current measurement/map preparation before running the OCR self-check.');
      return false;
    }
    checking = true;
    const button = document.getElementById('ocr-self-test');
    const extract = document.getElementById('processButton');
    const wasDisabled = extract?.disabled;
    if (button) button.disabled = true;
    if (extract) extract.disabled = true;
    status('Starting local OCR and reading a generated test number…');
    let worker;
    try {
      worker = await createWorker('primary');
      const canvas = document.createElement('canvas');
      canvas.width = 600; canvas.height = 160;
      const context = canvas.getContext('2d');
      context.fillStyle = '#fff'; context.fillRect(0,0,600,160);
      context.fillStyle = '#000'; context.font = '64px Arial';
      context.fillText('12345', 55, 105);
      await worker.setParameters({tessedit_pageseg_mode:'7', tessedit_char_whitelist:'0123456789', user_defined_dpi:'300'});
      let checkTimer, result;
      try {
        result = await Promise.race([
          worker.recognize(canvas, {}, {text:true}),
          new Promise((_, reject) => {
            checkTimer = setTimeout(() => reject(fail('OCR-CHECK-TIMEOUT', 'The OCR engine loaded, but its generated-number check timed out.')), 30000);
          }),
        ]);
      } finally { clearTimeout(checkTimer); }
      if (String(result?.data?.text || '').replace(/\s/g,'') !== '12345') {
        throw fail('OCR-SELF-CHECK', 'The OCR engine started, but its generated-number check did not match. Do not trust automatically read values until this is resolved.');
      }
      status('Passed: the local OCR library, worker, recognition engine, and English model loaded and read 12345 correctly. Select your ZIP, extract, and verify each measurement.', 'pass');
      return true;
    } catch (error) {
      status((typeof error?.code === 'string' && error.code.startsWith('OCR-')) ? error.message : 'The local OCR check failed. Use the Basic calculator with source-verified measurements.', 'error');
      return false;
    } finally {
      if (worker) await worker.terminate().catch(() => {});
      if (button) button.disabled = false;
      if (extract) extract.disabled = wasDisabled;
      checking = false;
    }
  }
  document.addEventListener('DOMContentLoaded', () => {
    status(libraryReady() ? 'OCR library bundled and ready. The recognition engine starts when you extract or run the self-check.' : 'OCR library not ready. Run the self-check to retry the local library.');
    document.getElementById('ocr-self-test')?.addEventListener('click', selfCheck);
  });
  return Object.freeze({version: VERSION, ensureLibrary, createWorker, selfCheck});
})();
