# Verification — NKPI 9.1.5.3 extraction upgrade

Source: `NKPI_v9152_OCR_Repair_GitHub.zip`, SHA-256
`98ca30e3d54a0c4c1d6e6301ea6c32794e0a373227d92663f4609c0ae86fcfc2`.

This is an engineering verification record. Synthetic tests are not clinical accuracy
validation and do not establish extraction speed on clinic hardware.

## Completed checks

- 47 Python tests pass (original model/domain/evidence and packaging tests retained).
- 26 JavaScript test scripts pass, including bounded study scheduling, parameter/read
  locking, cancellation and cache lifetime, exact-label crop location, wrong-unit and
  adjacent-number rejection, and late-map binding identity tests.
- 12 browser checks pass. Real bundled engines, workers, WebAssembly and English
  weights were used for the OCR checks. Two primary readers each returned
  `7.20 5.80 480 52.0 5.20 260` from a synthetic image; the secondary reader returned
  `12345`. The actual anchored crop routine read synthetic Kmax 52.0, ARTmax 260 and
  PPImax 1.85 from a labeled synthetic panel.
- Controlled workflow tests used real ZIP opening and browser UI orchestration with
  explicitly simulated study-reader/map delays. They verified two active independent
  workers, ordered/eye-isolated outputs, measurements visible before held map work,
  unchanged input DOM and manual edits when maps finish, canceled results and source
  URLs discarded, shared-pool longitudinal date ordering, map cancellation/restart,
  stable map source identities, and reset cleanup.
- The actual regional controller's binding logic permits enrichment of the same
  source/eye/visit while continuing to reject a changed source, changed numeric input
  snapshot, or dirty inputs. Its rendering was stubbed for that identity test only.
- Exactly 100 synthetic bilateral payloads (200 eyes: 100 baseline, 100 longitudinal)
  produced identical full returned calculation/audit/evidence structures versus the
  source. UI version was excluded; PDF generation was disabled. Random fixture seed 9153.
- All three model files, 13 cornea files and 17 OCR/vendor/model assets are unchanged.
  The regional controller and image-map math are also unchanged.
- Importer contains 23 inline scripts, each covered by its exact CSP hash; it does not
  require separate startup script downloads. The existing worker/core/model transport
  and OCR self-check are retained. Required OCR assets remain self-hosted.

## New behavior and safeguards

Complete, printed-label numeric crops augment the existing reading pipeline. They do
not infer measurements from plausibility, staging grades, another eye, or NKPI output.
Previously label-bound high-confidence conflicts veto automatic replacement. Existing
source confirmation and verification passes remain mandatory. Some ambiguous cases
will need more review rather than be auto-filled.

Page pixels are decoded once where the same Blob is reused, without changing width or
height. This memory-only cache is bounded and cleared on reset/completion. No OCR
result cache contributes votes. Browser persistence is limited to versioned static
traineddata; uncached startup remains available when storage is rejected.

Elapsed times from mocked-delay workflow tests are NOT clinical performance results.
The downloadable in-app diagnostic records durations and counts only. It contains no
patient names, filenames, exam dates, images, extracted strings or measurement values.

## Browser/environment limitations

Chromium used the generated production extractor with actual library/worker/model
bytes. Browser URL navigation is blocked in this environment; tests used set_content,
an explicit fixture base, and intercepted local static GETs. The fixture host was added
to CSP self-origin slots, with exact inline-script hashes still enforced. Parent-directed
extractor messages to the absent/opaque parent were suppressed. No patient-file upload
requests were introduced. This is not a live Streamlit/Community Cloud session.

Streamlit 1.50.0 could not be installed from the available package host. Python tests
ran on 3.13; existing deployment target is 3.12. No clinic network, managed Windows
browser, patient report-to-score run, held-out actual Pentacam field-accuracy benchmark,
or clinical speed distribution was tested. Existing PDF export and anatomical accuracy
were not newly validated. Additional layouts/text-layer/proprietary parsing and early
OCR stopping remain deferred. No new clinical accuracy/speed percentage is claimed.

## Reproduce the packaged software checks

From the extracted internal runtime, run `python -m pytest -q` and each `tests/*.cjs`
with Node.js. `python tools/verify_package.py` checks the file manifest. The optional
`tools/check_extraction_browser.py` needs Playwright and a Chromium executable; it uses
synthetic fixtures only and writes outputs to a temporary testing directory. Browser
test dependencies are not added to the production requirements.

Machine-readable summaries are in `docs/extraction_upgrade_checks/` inside the runtime.
