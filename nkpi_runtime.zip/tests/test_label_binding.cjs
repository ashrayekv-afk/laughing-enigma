'use strict';
const assert=require('node:assert/strict'),bind=require('../components/extractor/label_binding.js');
function line(parts,y=20,dx=0,scale=1){let x=dx;return {words:parts.map(s=>{const width=Math.max(7,s.length*7),w={text:s,confidence:95,bbox:{x0:x*scale,x1:(x+width)*scale,y0:y*scale,y1:(y+14)*scale}};x+=width+5;return w;})};}
for(const [parts,key,literal] of [
 [['ARC','(3mm','Zone):','7.20','mm','A','1'],'A','7.20'],
 [['PRC','(3mm','Zone):','5.80','mm','B','2'],'B','5.80'],
 [['Thinnest','Pachy:','480','µm'],'C','480'],
 [['Kmax:','52.0','D'],'Kmax','52.0'],
 [['ARTmax:','260'],'ARTmax','260'],
 [['D:','-','0.25'],'BAD_D','-0.25'],
 [['Df:','1.20','Db:','2.30','D:','5.20'],'BAD_D','5.20'],
 [['Max:','1.85'],'PPImax','1.85'],
]){const r=bind.find([line(parts)],key);assert(r.field,parts.join(' '));assert.equal(r.field.literal,literal);}
for(const [parts,key] of [
 [['A','2.0'],'A'],[['PRC','(3mm','Zone):','5.80','µm'],'B'],[['Pachy','Apex:','520'],'C'],
 [['ARTavg:','260'],'ARTmax'],[['Df:','5.20'],'BAD_D'],[['ARTmax:','260'],'PPImax'],
 [['Kmax:','52.0','55.0'],'Kmax'],
])assert.equal(bind.find([line(parts)],key).field,null,parts.join(' '));
assert.equal(bind.find([line(['ARTmax:','260']),line(['ARTmax:','280'],50)],'ARTmax').field,null);
const low=line(['ARTmax:','260']);low.words[0].confidence=30;assert.equal(bind.find([low],'ARTmax').field,null);
const base=bind.find([line(['ARTmax:','260'],20)],'ARTmax').field;
const scaled=bind.find([line(['ARTmax:','260'],20,0,2)],'ARTmax').field;
assert.deepEqual(bind.reference(base,[540,240,920,445],{width:1200,height:902},4),bind.reference(scaled,[540,240,920,445],{width:2400,height:1804},4));
assert(bind.reference(base,[540,240,920,445],{width:1200,height:902},4).completeBox);
console.log('PASS exact raw labels, final D versus components, ARTmax versus PPI, stage/apex rejection, unit checks, complete sign, duplicates/adjacent values, low confidence and resolution invariance.');
