/* Complete numeric-word crops bound to explicit printed measurement labels.
 * Locates evidence only. Never supplies a model input without the existing readers.
 */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.NKPILabelBinding=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const labels={
 A:/\bARC\s*[\[(]?\s*3\s*mm\s*Zone\s*[\])}]?\s*:*/i,
 B:/\bPRC\s*[\[(]?\s*3\s*mm\s*Zone\s*[\])}]?\s*:*/i,
 C:/\b(?:Thinnest\s*Pachy(?:metry)?|Pachy\s*Thin(?:\s*Locat\.?)?)\s*:*/i,
 Kmax:/\bK\s*max\s*(?:[\[(]\s*Front\s*[\])])?\s*:*/i,
 ARTmax:/\bART\s*max\s*:*/i,
 PPImax:/\bMax\s*:/i,
 BAD_D:/(?:^|\s)D\s*:/,
};
function validBox(b){return b&&['x0','x1','y0','y1'].every(k=>Number.isFinite(b[k]))&&b.x1>b.x0&&b.y1>b.y0;}
function union(words){return {x0:Math.min(...words.map(w=>w.bbox.x0)),y0:Math.min(...words.map(w=>w.bbox.y0)),x1:Math.max(...words.map(w=>w.bbox.x1)),y1:Math.max(...words.map(w=>w.bbox.y1))};}
function find(lines,variable){
 const found=[];let rejected=0;
 for(const line of lines||[]){
  const words=(line.words||[]).filter(w=>validBox(w.bbox)&&typeof w.text==='string');if(!words.length)continue;
  let text='',position=0;const ranges=words.map(w=>{const start=position;text+=(position?' ':'')+w.text;if(position)position++;const a=position;position+=w.text.length;return {w,start:a,end:position};});
  const match=text.match(labels[variable]);if(!match)continue;
  if(variable==='PPImax'&&/(?:ART|K)\s*max/i.test(text))continue;
  const end=match.index+match[0].length;
  const labelWords=ranges.filter(r=>r.end>match.index&&r.start<end).map(r=>r.w);
  const after=ranges.filter(r=>r.start>=end).map(r=>r.w);
  // A merged label/value word cannot give a precise independent number box.
  if(!labelWords.length||!after.length){rejected++;continue;}
  const lb=union(labelWords);let i=0;
  while(i<after.length&&/^[:|\[\]]+$/.test(after[i].text))i++;
  const numeric=[];
  for(;i<after.length;i++){
   const w=after[i],t=w.text.trim();
   if(!/^[+\-−–]?\d+(?:[.,]\d+)?(?:mm|[µμu]m|D)?$|^[+\-−–.,]$/.test(t))break;
   if(numeric.length){const prev=numeric[numeric.length-1],h=Math.max(prev.bbox.y1-prev.bbox.y0,w.bbox.y1-w.bbox.y0);
    const joined=numeric.map(v=>v.text).join('');
    // Join isolated sign/decimal glyphs, not two neighboring printed numbers.
    if(w.bbox.x0-prev.bbox.x1>h*.75||(!/[+\-−–.,]$/.test(joined)&&! /^[.,]$/.test(t)))break;
   }
   numeric.push(w);
  }
  if(!numeric.length){rejected++;continue;}
  const nb=union(numeric),h=Math.max(nb.y1-nb.y0,lb.y1-lb.y0),token=numeric.map(w=>w.text.trim()).join('');
  const suffix=token.match(/(mm|[µμu]m|D)$/i)?.[0]||after[i]?.text?.trim();
  const expected={A:'mm',B:'mm',C:'um',Kmax:'d'}[variable];
  const unit=String(suffix||'').toLowerCase().replace(/[µμ]/g,'u');
  const wrongUnit=expected&&['mm','um','d'].includes(unit)&&unit!==expected;
  if(wrongUnit||nb.x0<lb.x1-1||nb.x0-lb.x1>h*10||Math.abs((nb.y0+nb.y1-lb.y0-lb.y1)/2)>h*.8){rejected++;continue;}
  // A second literal number before the next label makes the association ambiguous.
  if(after[i]&&/^[+\-]?\d+(?:[.,]\d+)?$/.test(after[i].text.trim())){rejected++;continue;}
  const confidence=Math.min(...labelWords.map(w=>Number(w.confidence)||0));
  if(confidence<70){rejected++;continue;}
  found.push({number:nb,label:lb,row:union([...labelWords,...numeric]),literal:token,labelConfidence:confidence});
 }
 return {field:found.length===1&&rejected===0?found[0]:null,ambiguous:found.length>1||rejected>0,matches:found.length};
}
function reference(field,region,bitmap,scale,padding=0){
 const sx=scale*bitmap.width/1200,sy=scale*bitmap.height/902;
 const convert=(b,pad)=>[Math.max(0,region[0]+(b.x0-padding)/sx-pad),Math.max(0,region[1]+(b.y0-padding)/sy-pad),Math.min(1200,region[0]+(b.x1-padding)/sx+pad),Math.min(902,region[1]+(b.y1-padding)/sy+pad)];
 return {valueBox:convert(field.number,2.5),rowBox:convert(field.row,4),labelBox:convert(field.label,2),literal:field.literal,completeBox:true,anchor:'printed-label',labelConfidence:field.labelConfidence};
}
return Object.freeze({find,reference,validBox});
});
