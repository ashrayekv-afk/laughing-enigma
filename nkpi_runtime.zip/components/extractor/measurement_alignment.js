/* Layout-following refinement for unresolved fields, preserving all legacy passes.
 * A locator selects a complete printed crop, not the most plausible value. */
'use strict';
function boundFields(read,variables,region,bitmap,scale,padding=0){
 const output={};for(const key of variables){
  const located=NKPILabelBinding.find(ocrLines(read?.blocks),key);
  if(located.field)output[key]=NKPILabelBinding.reference(located.field,region,bitmap,scale,padding);
 }
 return output;
}
const originalRefinement=refineExtractionEvidence;
refineExtractionEvidence=async function(args){
 await originalRefinement(args);
 const {worker,values,audit,progression,topometricBitmap,belinBitmap,abcPanel}=args;
 const epoch=window.NKPIExtractionFlow?.workerEpoch(worker)??state.processEpoch;
 const current=()=>epoch===state.processEpoch;
 if(!current())throw NKPIExtractionFlow.cancelled();
 const missingABC=['A','B','C'].filter(k=>!audit[k].autoConfirmed);
 let abc={};
 if(missingABC.length){
  // Reuse the existing labeled-panel OCR before requesting another layout read.
  abc=boundFields(abcPanel?.result,missingABC,CROPS.TOPOMETRIC_ABC_PANEL,topometricBitmap,4,24);
  const absent=missingABC.filter(k=>!abc[k]);
  if(absent.length){
   const region=CROPS.TOPOMETRIC_ABC_SEARCH_BROAD,scale=3;
   const read=await recognize(worker,makeCropCanvas(topometricBitmap,region,scale),{psm:6});
   Object.assign(abc,boundFields(read,absent,region,topometricBitmap,scale));
  }
 }
 const belin=Object.fromEntries(['Kmax','ARTmax'].filter(k=>args.panel?.anchored?.fields?.[k]?.completeBox)
   .map(k=>[k,args.panel.anchored.fields[k]]));
 if(!audit.BAD_D.autoConfirmed){
  const region=CROPS.BAD_D_BOTTOM_ROW,scale=4;
  const read=await recognize(worker,makeCropCanvas(belinBitmap,region,scale),{psm:6});
  Object.assign(belin,boundFields(read,['BAD_D'],region,belinBitmap,scale));
 }
 for(const key of NKPIImport.FIELDS){
  if(audit[key].autoConfirmed)continue;
  if(!current())throw NKPIExtractionFlow.cancelled();
  const location=abc[key]||belin[key];if(!location?.completeBox)continue;
  const bitmap=['A','B','C'].includes(key)?topometricBitmap:belinBitmap;
  try{
   const read=await rereadLabeledNumber(worker,bitmap,location.valueBox,location.rowBox,key,null,true);
   if(!current())throw NKPIExtractionFlow.cancelled();
   const item=audit[key],prior=item.sources?.verifiedRead;
   read.family={A:'KC staging',B:'KC staging',C:'KC staging',Kmax:'Belin display',ARTmax:'Belin ARTmax',BAD_D:'Belin final D'}[key];
   Object.assign(read,{completeBox:true,anchor:'printed-label',rowBox:location.rowBox,valueBox:location.valueBox});
   item.sources ||= {};
   if(prior)item.sources.priorCropRead=prior;
   // An explicit conflict from a previously label-bound numeric read vetoes
   // automatic replacement even if the new crop's readers agree.
   const conflict=Number.isFinite(read.value)&&prior?.reads?.some(r=>Number.isFinite(r.value)&&r.confidence>=80&&Math.abs(r.value-read.value)>DIRECT_PRECISION[key]);
   if(conflict){read.passed=false;read.anchorConflict=true;item.bindingIssue='Label-bound rereads disagree. Confirm the printed measurement; neither candidate was selected automatically.';}
   item.sources.verifiedRead=read;
   if(read.passed){values[key]=read.value;if(key==='ARTmax')item.sources.derivedFallback='no';}
  }catch(error){if(!current())throw error;audit[key].alignmentNote='Full-label crop could not be resolved. Source review retained.';}
 }
 enforceExtractionIntegrity(values,audit,progression);
};
