from pathlib import Path
import json, mimetypes, time, traceback
from playwright.sync_api import sync_playwright
import tempfile, os
ROOT=Path(__file__).resolve().parents[1]; OUT=Path(tempfile.mkdtemp(prefix='nkpi-browser-check-'))
print('Synthetic browser check output:', OUT)
ORIGIN='https://nkpi-fixture.invalid'
report={'checks':[], 'page_errors':[], 'requests':[], 'environment':'Chromium; actual bundled scripts, OCR workers and model weights; static same-origin assets intercepted locally; browser navigation/Streamlit deployment unavailable. UI orchestration tests explicitly use controlled study-reader/map delays.'}
def record(name,data):
 report['checks'].append({'name':name,'result':'pass','data':data}); print(name, json.dumps(data)[:1000],flush=True)
def content():
 s=(ROOT/'components/extractor/index.html').read_text()
 s=s.replace('<head>','<head><base href="'+ORIGIN+'/components/extractor/index.html">',1)
 for kind in ['default-src','script-src','worker-src','connect-src','base-uri','img-src']:
  s=s.replace(kind+" 'self'",kind+" 'self' "+ORIGIN)
 return s
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 ctx=b.new_context(viewport={'width':1440,'height':1000})
 page=ctx.new_page();page.on('pageerror',lambda e: report['page_errors'].append(str(e)))
 def route(req):
  url=req.request.url
  if url.startswith(ORIGIN+'/'):
   relative=url.split(ORIGIN+'/',1)[1].split('?',1)[0]
   path=(ROOT/relative).resolve()
   if not path.is_relative_to(ROOT) or not path.is_file():return req.fulfill(status=404,body='missing')
   report['requests'].append({'path':relative,'method':req.request.method})
   mime=mimetypes.guess_type(str(path))[0] or 'application/octet-stream'
   req.fulfill(status=200,body=path.read_bytes(),content_type=mime,headers={'Access-Control-Allow-Origin':'*'})
  elif url.startswith(('data:','blob:')):req.continue_()
  else:req.abort()
 ctx.route('**/*',route)
 # Opaque test document has no actual Streamlit parent. Suppress only parent UI messages.
 page.evaluate("""() => {const post=window.postMessage.bind(window);window.postMessage=(message,...args)=>{if(message?.type?.startsWith('nkpi:extractor:'))return;return post(message,...args);};} """)
 try:
  page.set_content(content(),wait_until='domcontentloaded',timeout=30000)
  checks=page.evaluate("""() => ({version:APP_VERSION, flow:typeof NKPIExtractionFlow.map, alignment:typeof NKPILabelBinding.find, ready:typeof processFiles, library:typeof Tesseract.createWorker, errors:document.getElementById('errorBox').textContent})""")
  assert checks['version']=='9.1.5.3-extraction-upgrade' and checks['flow']=='function'
  record('inline_script_startup',checks)
  t=time.perf_counter();result=page.evaluate('() => NKPIOCR.selfCheck()');assert result
  record('actual_primary_engine_self_check',{'passed':result,'seconds':round(time.perf_counter()-t,2),'status':page.locator('#ocr-runtime-status').inner_text()})
  result=page.evaluate("""async () => {
    const workers=await ensureWorkers();const canvas=document.createElement('canvas');canvas.width=1500;canvas.height=150;
    const c=canvas.getContext('2d');c.fillStyle='white';c.fillRect(0,0,1500,150);c.fillStyle='black';c.font='48px Arial';c.fillText('7.20 5.80 480 52.0 5.20 260',30,90);
    let active=0,peak=0;const start=performance.now();
    const results=await NKPIExtractionFlow.map([0,1],workers,state.processEpoch,()=>true,async(_,w)=>{active++;peak=Math.max(peak,active);try{return (await recognize(w,canvas,{psm:7})).text;}finally{active--;}});
    return {results,peak,seconds:(performance.now()-start)/1000};
  }""")
  assert result['peak']==2 and all(x.strip()=='7.20 5.80 480 52.0 5.20 260' for x in result['results'])
  record('actual_two_worker_numeric_recognition',result)
  result=page.evaluate("""async () => {
    const w=await ensureSecondaryWorker();const canvas=document.createElement('canvas');canvas.width=650;canvas.height=150;const c=canvas.getContext('2d');c.fillStyle='white';c.fillRect(0,0,650,150);c.fillStyle='black';c.font='48px Arial';c.fillText('12345',20,90);
    return (await NKPIExtractionFlow.exclusive(w,state.processEpoch,()=>true,x=>recognize(x,canvas,{psm:7}))).text;
  }""")
  assert result.strip()=='12345';record('actual_secondary_engine',{'recognized':result})
  result=page.evaluate("""async () => {
    const bitmap=document.createElement('canvas');bitmap.width=1200;bitmap.height=902;const c=bitmap.getContext('2d');c.fillStyle='white';c.fillRect(0,0,1200,902);c.fillStyle='black';c.font='16px Arial';
    c.fillText('Kmax: 52.0 D',580,285);c.fillText('Max: 1.85',580,345);c.fillText('ARTmax: 260',580,390);
    const workers=await ensureWorkers();const r=await NKPIExtractionFlow.exclusive(workers[0],state.processEpoch,()=>true,w=>readAnchoredBelinFields(w,bitmap));
    const b=await new Promise(resolve=>bitmap.toBlob(resolve,'image/png'));const a=await blobToBitmap(b),d=await blobToBitmap(b);
    return {fields:Object.fromEntries(Object.entries(r.fields).map(([k,v])=>[k,{value:v.value,completeBox:v.completeBox,box:v.valueBox}])),reused:a===d};
  }""")
  assert result['reused'] and result['fields']['ARTmax']['value']==260 and result['fields']['Kmax']['value']==52
  assert all(f['completeBox'] for f in result['fields'].values())
  record('real_label_locating_and_full_number_crops',result)
  page.evaluate('async () => {await Promise.allSettled(state.workers.map(w=>w.terminate()));state.workers=[];if(secondaryWorker)await secondaryWorker.terminate();secondaryWorker=null;}')
  sim=page.evaluate("""async () => {
   window.sim={active:0,peak:0,completed:0,releaseMaps:[],workDelay:35,mapHold:true};
   const workers=[{id:'worker-0'},{id:'worker-1'}];
   ensureWorkers=async()=>{state.workers=workers;return workers;};
   const cvs=document.createElement('canvas');cvs.width=1200;cvs.height=902;const cx=cvs.getContext('2d');cx.fillStyle='white';cx.fillRect(0,0,1200,902);const blob=await new Promise(r=>cvs.toBlob(r,'image/png'));
   window.makeFixtureFile=async(date='20260101120000')=>{const z=new JSZip();for(const eye of ['OD','OS'])for(const suffix of ['-0006','-0011'])z.file(eye+'-'+date+'.PdfReport.0000'+suffix+'.png',await blob.arrayBuffer());return new File([await z.generateAsync({type:'arraybuffer'})],'synthetic-export.zip',{type:'application/zip'});};
   window.setFixture=async(id,date)=>{const dt=new DataTransfer();dt.items.add(await makeFixtureFile(date));el(id).files=dt.files;};
   extractStudy=async(d,w)=>{sim.active++;sim.peak=Math.max(sim.peak,sim.active);await new Promise(r=>setTimeout(r,sim.workDelay));sim.active--;sim.completed++;
    const eye=d.prefix.startsWith('OS')?'OS':'OD';const values={A:eye==='OD'?7.20:7.35,B:5.80,C:480,Kmax:52.0,BAD_D:5.20,ARTmax:260};
    const source=registerPreviewUrl(blob);return deferReportPages(d,{eye,timestamp:d.timestamp,values,audit:Object.fromEntries(Object.keys(values).map(k=>[k,{final:values[k],autoConfirmed:true,quality:'High',statusLabel:'Auto-read',sources:{}}])),manualEdits:{},fieldPreviews:{},fieldPreviewNotes:{},sourcePages:{topometric:source,belin:source},complete:true,scanQuality:'unknown'});
   };
   attachAssociatedReportPages=async(d,s)=>{if(sim.mapHold)await new Promise(r=>sim.releaseMaps.push(r));else await new Promise(r=>setTimeout(r,20));s.reportMapNotice='Controlled map fixture complete';return s;};
   el('age').value='30';await setFixture('baselineZip','20260101120000');await processFiles();
   return {peak:sim.peak,measurements:state.baselineStudies.length,reviewVisible:!el('reviewSection').classList.contains('hidden'),mapsRunning:nkpiMapsRunning(),readyText:el('extractionStages').textContent,input:el('baseline_OD_A')?.value};
  }""")
  assert sim['peak']==2 and sim['measurements']==2 and sim['reviewVisible'] and sim['mapsRunning']
  record('measurements_visible_before_map_completion_controlled',sim)
  result=page.evaluate("""async () => {
   window.bindingBefore=selectedReportSets().map(s=>[s.eye,s.visit,s.source_id]);window.editedNode=el('baseline_OD_A');editedNode.value='7.25';editedNode.dispatchEvent(new Event('input',{bubbles:true}));
   sim.mapHold=false;for(const r of sim.releaseMaps.splice(0))r();
   await new Promise(r=>setTimeout(r,100));
   return {bindingsStable:JSON.stringify(bindingBefore)===JSON.stringify(selectedReportSets().map(s=>[s.eye,s.visit,s.source_id])),sameNode:editedNode===el('baseline_OD_A'),value:el('baseline_OD_A').value,stored:state.baselineStudies.find(s=>s.eye==='OD').manualEdits.A.value,maps:state.baselineStudies.map(s=>s.mapPreparation),metrics:NKPIExtractionMetrics.snapshot()};
  }""")
  assert result['bindingsStable'] and result['sameNode'] and result['value']=='7.25' and all(s=='ready' for s in result['maps'])
  record('map_completion_preserves_input_node_and_manual_edit',result)
  result=page.evaluate("""async () => {
   sim.workDelay=100;sim.completed=0;sim.peak=0;window.oldRun=processFiles();await new Promise(r=>setTimeout(r,35));
   resetResultsOnly();await oldRun;
   return {studies:state.baselineStudies.length,reviewHidden:el('reviewSection').classList.contains('hidden'),processing:state.processing,buttonEnabled:!el('processButton').disabled,sourceCount:state.previewUrls.size};
  }""")
  assert result['studies']==0 and result['reviewHidden'] and not result['processing'] and result['buttonEnabled'] and result['sourceCount']==0
  record('cancelled_measurements_cannot_publish_to_new_case',result)
  result=page.evaluate("""async () => {
   sim.workDelay=20;sim.peak=0;sim.completed=0;sim.mapHold=false;document.querySelector('input[name=mode][value=longitudinal]').checked=true;setMode('longitudinal');
   await setFixture('earlierZip','20260601120000');await setFixture('laterZip','20260101120000');await processFiles();await new Promise(r=>setTimeout(r,100));
   return {peak:sim.peak,studies:sim.completed,first:state.earlierStudies.map(s=>({eye:s.eye,month:s.timestamp.getMonth()+1,A:s.values.A})),last:state.laterStudies.map(s=>({eye:s.eye,month:s.timestamp.getMonth()+1,A:s.values.A})),notice:state.visitOrderNotice};
  }""")
  assert result['peak']==2 and result['studies']==4 and all(s['month']==1 for s in result['first']) and all(s['month']==6 for s in result['last'])
  assert all(s['A']==(7.2 if s['eye']=='OD' else 7.35) for s in result['first']+result['last'])
  record('longitudinal_shared_pool_eye_and_date_isolation',result)
  result=page.evaluate("""async () => {
   resetResultsOnly();document.querySelector('input[name=mode][value=baseline]').checked=true;setMode('baseline');
   await setFixture('baselineZip','20260101120000');sim.mapHold=true;await processFiles();
   const ids=selectedReportSets().map(s=>s.source_id);cancelDeferredReportMaps();sim.mapHold=false;
   for(const r of sim.releaseMaps.splice(0))r();await new Promise(r=>setTimeout(r,60));
   const before=state.baselineStudies.map(s=>s.mapPreparation);
   await startDeferredReportMaps(state.processEpoch);
   return {before,after:state.baselineStudies.map(s=>s.mapPreparation),idsPreserved:JSON.stringify(ids)===JSON.stringify(selectedReportSets().map(s=>s.source_id)),values:state.baselineStudies.map(s=>s.values.A)};
  }""")
  assert all(x=='pending' for x in result['before']) and all(x=='ready' for x in result['after']) and result['idsPreserved']
  record('map_cancellation_then_safe_restart_preserves_study_binding',result)
  page.screenshot(path=str(OUT/'extraction_upgrade_review.png'),full_page=True)
  result=page.evaluate("""() => {resetResultsOnly();return {cacheBytes:decodedReportCache.bytes,urls:state.previewUrls.size,rows:el('reviewContent').children.length,metrics:NKPIExtractionMetrics.snapshot()};}""")
  assert result=={'cacheBytes':0,'urls':0,'rows':0,'metrics':None}
  record('case_reset_clears_images_review_and_metrics',result)
  assert not report['page_errors'],report['page_errors']
  record('no_script_errors_or_external_patient_uploads',{'pageErrors':len(report['page_errors']),'nonGET':sum(r['method']!='GET' for r in report['requests'])})
 except Exception:
  report['failure']=traceback.format_exc();print(report['failure'],flush=True)
 finally:
  (OUT/'browser_report.json').write_text(json.dumps(report,indent=2));b.close()
 if 'failure' in report:raise SystemExit(1)
