/* NKPI 9.1.5 — original natural-eye materials on the continuous v9.1.4 surface.
 * Presentation only. No geometry fitting, input edits, minima, or risk scoring.
 * Local shaders; no external textures or network dependencies. An offscreen
 * WebGL canvas is composited into the interactive 2D canvas for consistent PNGs.
 */
(function (root) {
'use strict';
const TAU = 2 * Math.PI;
const finite = Number.isFinite;
const unit = v => { const n = Math.hypot(...v) || 1; return v.map(x => x / n); };
const dot = (a,b) => a.reduce((s,x,i) => s + x*b[i], 0);
const sub = (a,b) => a.map((x,i) => x-b[i]);
const cross = (a,b) => [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];

function rotation(yaw, pitch) {
  const c=Math.cos(yaw),s=Math.sin(yaw),a=Math.cos(pitch),b=Math.sin(pitch);
  // Column-major; exactly the existing viewer's orthographic transform.
  return new Float32Array([c,b*s,-a*s, 0,a,b, s,-b*c,a*c]);
}
function referenceGeometry(model) {
  const radius=12,limbus=model.limbus,z=model.front(limbus,0)[2];
  return {radius,limbus,limbusZ:z,centerZ:z-Math.sqrt(radius*radius-limbus*limbus),irisZ:z-.48,irisRadius:limbus-.10};
}
function sphereMesh(ref) {
  const N=128,J=88,positions=[],normals=[],triangles=[],start=Math.asin(ref.limbus/ref.radius);
  for(let j=0;j<=J;j++) for(let i=0;i<N;i++) {
    const t=start+(Math.PI-start-1e-6)*j/J,a=TAU*i/N;
    const n=[Math.sin(t)*Math.cos(a),Math.sin(t)*Math.sin(a),Math.cos(t)];
    positions.push([n[0]*ref.radius,n[1]*ref.radius,ref.centerZ+n[2]*ref.radius]);normals.push(n);
  }
  for(let j=0;j<J;j++)for(let i=0;i<N;i++){
    const a=j*N+i,b=j*N+(i+1)%N,c=a+N,d=b+N;triangles.push([a,c,b],[b,c,d]);
  }
  return {positions,normals,triangles};
}
function irisMesh(ref) {
  const N=256,positions=[[0,0,ref.irisZ]],normals=[[0,0,1]],triangles=[];
  for(let i=0;i<N;i++){const a=TAU*i/N;positions.push([ref.irisRadius*Math.cos(a),ref.irisRadius*Math.sin(a),ref.irisZ]);normals.push([0,0,1]);}
  for(let i=0;i<N;i++)triangles.push([0,i+1,(i+1)%N+1]);
  return {positions,normals,triangles};
}
function normalField(points,triangles,reverse=false) {
  const n=points.map(()=>[0,0,0]);
  for(const ids of triangles){const [a,b,c]=ids,q=cross(sub(points[b],points[a]),sub(points[c],points[a]));if(q[2]<0)for(let k=0;k<3;k++)q[k]*=-1;
    for(const i of ids)for(let k=0;k<3;k++)n[i][k]+=q[k];}
  return n.map(v=>unit(v).map(x=>reverse?-x:x));
}
const VERTEX=`
attribute vec3 aPosition;
attribute vec3 aNormal;
attribute float aSupport;
uniform mat3 uRotation;
uniform vec2 uViewport;
uniform float uScale;
uniform float uPivotZ;
varying vec3 vNormal;
varying vec3 vLocal;
varying float vSupport;
void main(){
 vec3 p=uRotation*(aPosition+vec3(0.,0.,uPivotZ));
 gl_Position=vec4(p.x*uScale*2./uViewport.x,p.y*uScale*2./uViewport.y,-p.z/64.,1.);
 vNormal=uRotation*aNormal;vLocal=aPosition;vSupport=aSupport;
}`;
const FRAGMENT=`
precision highp float;
uniform int uMode;
uniform float uLimbus;
uniform float uSourceRadius;
uniform bool uHasMap;
uniform bool uShowSupport;
uniform sampler2D uMap;
varying vec3 vNormal;
varying vec3 vLocal;
varying float vSupport;
void main(){
 vec3 n=normalize(vNormal);if(!gl_FrontFacing)n=-n;
 vec3 key=normalize(vec3(-.65,.85,1.4));
 vec3 fill=normalize(vec3(.9,.15,.5));
 vec3 halfV=normalize(key+vec3(0.,0.,1.));
 float diffuse=max(0.,dot(n,key)),secondary=max(0.,dot(n,fill));
 float facing=abs(n.z),rim=pow(1.-facing,3.),spec=pow(max(0.,dot(n,halfV)),80.);
 if(uMode==0){
  float grain=sin(vLocal.x*41.+sin(vLocal.y*23.))*sin(vLocal.y*47.+vLocal.z*13.);
  vec3 base=vec3(.91,.935,.96)+grain*.0014;
  vec3 col=base*(.47+.45*diffuse+.10*secondary)+vec3(.10,.13,.17)*rim+vec3(.20)*spec;
  gl_FragColor=vec4(clamp(col,0.,1.),1.);return;
 }
 if(uMode==1){
  float r=length(vLocal.xy),a=atan(vLocal.y,vLocal.x),pr=1.74+.014*sin(a*83.)+.009*sin(a*119.);
  if(r<pr){gl_FragColor=vec4(.008,.014,.023,1.);return;}
  float t=clamp((r-pr)/(uLimbus-pr-.10),0.,1.);
  float warp=2.1*sin(r*1.8+a*7.)+.4*sin(r*4.7+a*19.)+.6*sin(a*29.);
  float fiber=.50+.22*sin(a*113.+warp)+.10*sin(a*197.-warp*1.4)+.05*sin(a*281.+r*3.2);
  float folds=.5+.5*sin(a*53.+sin(a*17.)*.6+r*.38),band=.80+.20*sin(t*10.+sin(a*29.)*.20);
  vec3 col=mix(vec3(.055,.130,.185),vec3(.185,.345,.430),clamp(fiber*.79+folds*.14,0.,1.))*band;
  col+=vec3(.020,.035,.038)*pow(clamp(fiber,0.,1.),2.3);
  col=mix(col,vec3(.08,.135,.15),.28*exp(-pow((t-.27)/.065,2.)));
  col*=1.-.76*smoothstep(.87,1.,t);col*=.56+.44*smoothstep(0.,.05,t);
  gl_FragColor=vec4(col*(.78+.23*diffuse),1.);return;
 }
 float rad=length(vLocal.xy);
 if(uMode==2){
  if(!uHasMap||rad>uSourceRadius)discard;
  // The unchanged map texture is intentionally unlit. Reflections never recolor a value.
  vec2 uv=vec2((vLocal.x/uSourceRadius+1.)*.5,(1.-vLocal.y/uSourceRadius)*.5);
  vec4 map=texture2D(uMap,clamp(uv,0.,1.));
  if(map.a<.01)discard;gl_FragColor=vec4(map.rgb,1.);return;
 }
 if(uMode==3||uMode==4){
  // Opaque quantitative colors are already drawn; only the clear peripheral shell remains.
  if(uHasMap&&rad<=uSourceRadius)discard;
  if(uShowSupport&&uMode==3){
    vec3 col=vSupport>.995?vec3(.22,.62,.72):vec3(.92,.68,.34);
    float hatch=step(.83,fract((gl_FragCoord.x+gl_FragCoord.y)/13.));
    if(vSupport<.995)col=mix(col,vec3(.98),hatch*.17);
    gl_FragColor=vec4(col,.82);return;
  }
  float fresnel=pow(1.-facing,1.4);
  float broad=pow(max(0.,dot(n,halfV)),55.);
  float pin=pow(max(0.,dot(n,normalize(vec3(-.38,.49,1.65)))),280.);
  vec3 reflection=mix(vec3(.67,.88,1.),vec3(.96,.985,1.),clamp(broad*.65+pin,0.,1.));
  float alpha=.02+.92*fresnel+.14*broad+.13*pin;
  if(uMode==4)alpha=.006+.065*fresnel;
  gl_FragColor=vec4(reflection,clamp(alpha,0.,.80));return;
 }
 gl_FragColor=vec4(.5,.6,.7,1.);
}`;
const BGV=`attribute vec2 aPosition;varying vec2 vUV;void main(){vUV=aPosition*.5+.5;gl_Position=vec4(aPosition,1.,1.);}`;
const BGF=`precision mediump float;varying vec2 vUV;uniform vec2 uViewport;
void main(){vec2 q=(vUV-vec2(.43,.6))*vec2(uViewport.x/uViewport.y,1.);float glow=exp(-dot(q,q)*4.);
vec3 bg=mix(vec3(.022,.031,.056),vec3(.060,.091,.146),glow*.78);
float shadow=exp(-pow((vUV.x-.52)*3.5,2.)-pow((vUV.y-.16)*15.,2.));gl_FragColor=vec4(bg*(1.-shadow*.40),1.);}`;
function program(gl,vs,fs){const shaders=[];let p;
 try{for(const [kind,text]of [[gl.VERTEX_SHADER,vs],[gl.FRAGMENT_SHADER,fs]]){const s=gl.createShader(kind);shaders.push(s);gl.shaderSource(s,text);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s)||'Shader compilation failed');}
  p=gl.createProgram();for(const s of shaders)gl.attachShader(p,s);gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(p)||'Shader link failed');return p;
 }catch(e){if(p)gl.deleteProgram(p);throw e;}finally{for(const s of shaders)gl.deleteShader(s);}}
class NaturalEyeBase {
 constructor({canvas=null,forceFallback=false}={}){
  this.canvas=canvas||document.createElement('canvas');this.available=false;this.error='';this.disposed=false;this.buffers=[];this.textures=[];this.programs=[];
  if(forceFallback){this.error='Canvas rendering requested';return;}
  try{this.gl=this.canvas.getContext('webgl',{alpha:false,antialias:true,depth:true,stencil:false,premultipliedAlpha:false,preserveDrawingBuffer:true,powerPreference:'low-power'});
    if(!this.gl){this.error='WebGL unavailable';return;}this.init();
    this.onLost=e=>{e.preventDefault();this.available=false;this.error='WebGL context lost; using Canvas rendering';};
    this.onRestore=()=>{if(this.disposed)return;this.buffers=[];this.textures=[];this.programs=[];this.model=null;this.scene=null;try{this.init();this.error='';}catch(e){this.available=false;this.error=e.message;}};
    this.canvas.addEventListener('webglcontextlost',this.onLost);this.canvas.addEventListener('webglcontextrestored',this.onRestore);
  }catch(e){this.available=false;this.error=e.message;this.cleanup();}
 }
 init(){const gl=this.gl;this.main=program(gl,VERTEX,FRAGMENT);this.bg=program(gl,BGV,BGF);this.programs.push(this.main,this.bg);this.attrs={};
  for(const a of ['aPosition','aNormal','aSupport'])this.attrs[a]=gl.getAttribLocation(this.main,a);this.u={};
  for(const k of ['uRotation','uViewport','uScale','uPivotZ','uMode','uLimbus','uSourceRadius','uHasMap','uShowSupport','uMap'])this.u[k]=gl.getUniformLocation(this.main,k);
  this.quad=this.buffer(new Float32Array([-1,-1,1,-1,-1,1,1,1]));this.available=true;
 }
 buffer(array,target){const gl=this.gl,b=gl.createBuffer();this.buffers.push(b);gl.bindBuffer(target||gl.ARRAY_BUFFER,b);gl.bufferData(target||gl.ARRAY_BUFFER,array,gl.STATIC_DRAW);return b;}
 geometry(positions,normals,triangles,support=null){const gl=this.gl,a=new Float32Array(positions.length*7);if(positions.length>65535)throw Error('Surface exceeds supported render index range');
  positions.forEach((p,i)=>{if(!p.every(finite))throw Error('Nonfinite display coordinate');a.set(p,i*7);a.set(normals[i],i*7+3);a[i*7+6]=support?support[i]:1;});
  const indices=triangles.map(ids=>{const [a,b,c]=ids,q=cross(sub(positions[b],positions[a]),sub(positions[c],positions[a]));return dot(q,normals[a])<0?[a,c,b]:ids;}).flat();
  return {buffer:this.buffer(a),index:this.buffer(new Uint16Array(indices),gl.ELEMENT_ARRAY_BUFFER),count:indices.length};
 }
 build(model,mesh){if(this.model===model)return;
  const gl=this.gl;for(const b of this.buffers.splice(1))gl.deleteBuffer(b);for(const t of this.textures)gl.deleteTexture(t);this.textures=[];this.textureSource=null;
  this.model=model;const ref=referenceGeometry(model),s=sphereMesh(ref),i=irisMesh(ref);
  const front=this.geometry(mesh.points,mesh.normals,mesh.triangles,mesh.points.map(p=>model.geometrySupported(p[0],p[1])?1:0));
  const back=this.geometry(mesh.back,normalField(mesh.back,mesh.triangles,true),mesh.triangles);
  this.scene={ref,front,back,sclera:this.geometry(s.positions,s.normals,s.triangles),iris:this.geometry(i.positions,i.normals,i.triangles)};
  this.mapTexture=gl.createTexture();this.textures.push(this.mapTexture);gl.bindTexture(gl.TEXTURE_2D,this.mapTexture);
  gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([0,0,0,0]));
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
 }
 draw(g,mode){if(!g.count)return;const gl=this.gl;gl.bindBuffer(gl.ARRAY_BUFFER,g.buffer);
  for(const [a,size,offset]of [['aPosition',3,0],['aNormal',3,12],['aSupport',1,24]]){const loc=this.attrs[a];gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,size,gl.FLOAT,false,28,offset);}
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,g.index);gl.uniform1i(this.u.uMode,mode);gl.drawElements(gl.TRIANGLES,g.count,gl.UNSIGNED_SHORT,0);
 }
 render({model,mesh,width,height,scale,yaw,pitch,pivotZ=1.2,mapCanvas=null,support=false,pixelRatio=1}){
  if(!this.available||this.disposed)return false;const gl=this.gl;
  try{this.build(model,mesh);const w=Math.max(1,Math.round(width*pixelRatio)),h=Math.max(1,Math.round(height*pixelRatio));if(this.canvas.width!==w||this.canvas.height!==h){this.canvas.width=w;this.canvas.height=h;}
   gl.viewport(0,0,w,h);gl.disable(gl.BLEND);gl.disable(gl.CULL_FACE);gl.disable(gl.DEPTH_TEST);gl.depthMask(true);gl.clearColor(.025,.035,.06,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
   gl.useProgram(this.bg);const a=gl.getAttribLocation(this.bg,'aPosition');for(let j=0;j<gl.getParameter(gl.MAX_VERTEX_ATTRIBS);j++)gl.disableVertexAttribArray(j);
   gl.bindBuffer(gl.ARRAY_BUFFER,this.quad);gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a,2,gl.FLOAT,false,0,0);gl.uniform2f(gl.getUniformLocation(this.bg,'uViewport'),width,height);gl.drawArrays(gl.TRIANGLE_STRIP,0,4);
   gl.useProgram(this.main);gl.uniformMatrix3fv(this.u.uRotation,false,rotation(yaw,pitch));gl.uniform2f(this.u.uViewport,width,height);gl.uniform1f(this.u.uScale,scale);gl.uniform1f(this.u.uPivotZ,pivotZ);gl.uniform1f(this.u.uLimbus,model.limbus);gl.uniform1f(this.u.uSourceRadius,model.radius);gl.uniform1i(this.u.uHasMap,mapCanvas?1:0);gl.uniform1i(this.u.uShowSupport,support?1:0);
   gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,this.mapTexture);gl.uniform1i(this.u.uMap,0);
   if(mapCanvas&&this.textureSource!==mapCanvas){gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,false);gl.pixelStorei(gl.UNPACK_COLORSPACE_CONVERSION_WEBGL,gl.NONE);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,mapCanvas);this.textureSource=mapCanvas;}
   gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.enable(gl.CULL_FACE);gl.cullFace(gl.BACK);gl.frontFace(gl.CCW);
   this.draw(this.scene.sclera,0);this.draw(this.scene.iris,1);
   if(mapCanvas)this.draw(this.scene.front,2);
   gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.depthMask(false);
   // Subtle inner contour first, then the continuous outer shell. No wedge removal.
   gl.disable(gl.CULL_FACE);this.draw(this.scene.back,4);gl.enable(gl.CULL_FACE);this.draw(this.scene.front,3);
   gl.depthMask(true);gl.disable(gl.BLEND);gl.flush();return true;
  }catch(e){this.error=e.message;this.available=false;return false;}
 }
 cleanup(){const gl=this.gl;if(!gl)return;for(const b of this.buffers)gl.deleteBuffer(b);for(const t of this.textures)gl.deleteTexture(t);for(const p of this.programs)gl.deleteProgram(p);this.buffers=[];this.textures=[];this.programs=[];this.scene=null;this.model=null;this.textureSource=null;}
 dispose(){if(this.disposed)return;this.disposed=true;this.available=false;if(this.onLost)this.canvas.removeEventListener('webglcontextlost',this.onLost);if(this.onRestore)this.canvas.removeEventListener('webglcontextrestored',this.onRestore);this.cleanup();this.gl?.getExtension('WEBGL_lose_context')?.loseContext();}
}
// Shader-free smooth transparency for machines where WebGL is disabled.
// Rasterizes the same display vertices with interpolated normals; no point is moved.
function drawSoftwareShell(ctx,{model,mesh,projected,width,height,yaw,pitch,support=false}){
 const w=Math.max(1,Math.round(width)),h=Math.max(1,Math.round(height));
 const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;
 const c=canvas.getContext('2d'),im=c.createImageData(w,h),depth=new Float32Array(w*h);depth.fill(-Infinity);
 const r=rotation(yaw,pitch),normals=mesh.normals.map(n=>[0,1,2].map(i=>n[0]*r[i]+n[1]*r[i+3]+n[2]*r[i+6]));
 const evidence=support?mesh.points.map(p=>model.geometrySupported(p[0],p[1])?1:0):null;
 const light=unit([-.65,.85,1.4]),halfV=unit([light[0],light[1],light[2]+1]),pinV=unit([-.38,.49,1.65]);
 for(const ids of mesh.triangles){const [ia,ib,ic]=ids,[a,b,d]=ids.map(i=>projected[i]),[na,nb,nd]=ids.map(i=>normals[i]);
  const den=(b[1]-d[1])*(a[0]-d[0])+(d[0]-b[0])*(a[1]-d[1]);if(den>=-1e-8)continue;
  const x0=Math.max(0,Math.floor(Math.min(a[0],b[0],d[0]))),x1=Math.min(w-1,Math.ceil(Math.max(a[0],b[0],d[0])));
  const y0=Math.max(0,Math.floor(Math.min(a[1],b[1],d[1]))),y1=Math.min(h-1,Math.ceil(Math.max(a[1],b[1],d[1])));
  for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){
   const u=((b[1]-d[1])*(x+.5-d[0])+(d[0]-b[0])*(y+.5-d[1]))/den;
   const v=((d[1]-a[1])*(x+.5-d[0])+(a[0]-d[0])*(y+.5-d[1]))/den,t=1-u-v;if(u<0||v<0||t<0)continue;
   const z=u*a[2]+v*b[2]+t*d[2],k=y*w+x;if(z<depth[k])continue;depth[k]=z;
   let nx=u*na[0]+v*nb[0]+t*nd[0],ny=u*na[1]+v*nb[1]+t*nd[1],nz=u*na[2]+v*nb[2]+t*nd[2];
   const n=Math.hypot(nx,ny,nz)||1;nx/=n;ny/=n;nz/=n;let col,alpha;
   if(support){const known=u*evidence[ia]+v*evidence[ib]+t*evidence[ic]>.995;col=known?[56,158,184]:[235,173,87];alpha=.82;
    if(!known&&(x+y)%13>10)col=col.map(v=>v*.83+250*.17);
   }else{const fresnel=Math.pow(1-Math.min(1,Math.abs(nz)),1.4),broad=Math.pow(Math.max(0,nx*halfV[0]+ny*halfV[1]+nz*halfV[2]),55),pin=Math.pow(Math.max(0,nx*pinV[0]+ny*pinV[1]+nz*pinV[2]),280),blend=Math.min(1,broad*.65+pin);
    col=[.67+(.96-.67)*blend,.88+(.985-.88)*blend,1].map(v=>255*v);alpha=Math.min(.80,.02+.92*fresnel+.14*broad+.13*pin);
   }
   im.data.set([...col,Math.round(255*alpha)],k*4);
  }
 }
 c.putImageData(im,0,0);ctx.drawImage(canvas,0,0,width,height);
}
NaturalEyeBase.drawSoftwareShell=drawSoftwareShell;
NaturalEyeBase.version='9.1.5-original-natural-eye';
NaturalEyeBase.rotation=rotation;NaturalEyeBase.referenceGeometry=referenceGeometry;NaturalEyeBase.sphereMesh=sphereMesh;NaturalEyeBase.irisMesh=irisMesh;
if(typeof module!=='undefined'&&module.exports)module.exports=NaturalEyeBase;else root.NKPINaturalEyeBase=NaturalEyeBase;
})(typeof window!=='undefined'?window:globalThis);
