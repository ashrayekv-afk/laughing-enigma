"""Bundle the importer in one HTML response, with exact CSP hashes.

Workers, WASM and language weights remain same-origin files. This does not
embed any report/patient data or alter the measurement-extraction algorithms.
"""
from pathlib import Path
import re, hashlib, base64, html
ROOT = Path(__file__).resolve().parents[1] / 'components'
EXTRACTOR = ROOT / 'extractor'
text = (EXTRACTOR / 'index.template.html').read_text(encoding='utf-8')
blocks = []
hashes = []

def asset(name):
    path = (EXTRACTOR / name.split('?',1)[0]).resolve()
    if not path.is_relative_to(ROOT.resolve()):
        raise ValueError('Outside component assets')
    return path.read_text(encoding='utf-8')

def script(match):
    name = match.group(1)
    source = asset(name)
    # Source-map directives inside inline code must not fetch a wrong base path.
    source = re.sub(r'^//# sourceMappingURL=.*$', '', source, flags=re.M)
    source = re.sub(r'</script', r'<\\/script', source, flags=re.I)
    body = '\n' + source + '\n'
    hashes.append("'sha256-" + base64.b64encode(hashlib.sha256(body.encode('utf-8')).digest()).decode() + "'")
    blocks.append('<script data-nkpi-source="' + html.escape(name, quote=True) + '">' + body + '</script>')
    return ''

def style(match):
    name = match.group(1)
    source = asset(name)
    if '</style' in source.lower(): raise ValueError('Invalid style')
    return '<style data-nkpi-source="'+html.escape(name,quote=True)+'">\n'+source+'\n</style>'

text = re.sub(r'<script(?: defer)? src="([^"]+)"></script>', script, text)
text = re.sub(r'<link rel="stylesheet" href="([^"]+)"\s*/>', style, text)
# Preserve the original PDF-reader allowances; no unsafe-inline JS is enabled.
text = text.replace("script-src 'self' https://cdn.jsdelivr.net 'unsafe-eval';", "script-src 'self' https://cdn.jsdelivr.net 'unsafe-eval' " + ' '.join(hashes) + ';')
# Deferred scripts are moved after the existing DOM in original order.
text = text.replace('</body>', '\n'.join(blocks) + '\n</body>')
assert not re.search(r'<script[^>]+\bsrc=',text)
(EXTRACTOR / 'index.html').write_text(text, encoding='utf-8')
print(f'Built extractor: {len(blocks)} inline scripts; {len(hashes)} CSP hashes; {len(text.encode())} bytes')
