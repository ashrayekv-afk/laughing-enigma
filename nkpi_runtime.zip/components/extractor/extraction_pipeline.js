/* Stage measurements before optional viewer preparation. All state is local and
 * tied to one import generation. Viewer updates never rebuild edited input rows. */
'use strict';
const decodedReportCache=new NKPIExtractionFlow.BitmapCache(48*1024*1024);
let extractionRun=null,mapRunSequence=0;
const clock=()=>typeof performance!=='undefined'?performance.now():Date.now();
function pipelinePanel(){
 let box=el('extractionStages');if(box)return box;
 box=repairNode('div','notice');box.id='extractionStages';box.setAttribute('role','status');box.setAttribute('aria-live','polite');
 el('processButton').closest('section').append(box);
 const details=repairNode('details','extraction-details');details.id='extractionTimings';
 details.append(repairNode('summary','','Extraction timing (no patient information)'));
 const text=repairNode('p','muted');text.id='extractionTimingText';details.append(text);
 const button=repairNode('button','secondary','Download timing diagnostic');button.type='button';
 button.onclick=()=>{if(!extractionRun)return;const url=URL.createObjectURL(new Blob([JSON.stringify(pipelineMetrics(),null,2)],{type:'application/json'}));const link=repairNode('a');link.href=url;link.download='NKPI_extraction_timing.json';document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);};
 details.append(button);box.after(details);return box;
}
function pipelineMetrics(){
 if(!extractionRun)return null;
 const r=extractionRun,durations={...r.durations};if(r.phase&&!['complete','error'].includes(r.phase))durations[r.phase]=(durations[r.phase]||0)+clock()-r.phaseStart;
 return {schema:'nkpi-extraction-timing-1',release:'9.1.5.3-extraction-upgrade',phase:r.phase,
  measurements_ready_ms:r.reviewReady===null?null:Math.round(r.reviewReady),
  elapsed_ms:Math.round((r.finished??clock())-r.started),
  phase_ms:Object.fromEntries(Object.entries(durations).map(([k,v])=>[k,Math.round(v)])),
  recognition_calls:r.reads,studies:r.studies,viewer_studies_ready:r.mapsDone,
  decoded_image_reuse:r.cacheHits+decodedReportCache.hits,
  note:'Timing/counts only. No names, filenames, dates, report text, pixels, or measurement values.'};
}
function timingText(){
 const m=pipelineMetrics();if(!m)return;
 const text=el('extractionTimingText');if(text)text.textContent=
  (m.measurements_ready_ms===null?'Measurements pending':`Measurements ready in ${(m.measurements_ready_ms/1000).toFixed(1)} s`)+
  ` · ${m.recognition_calls} OCR reads · ${m.decoded_image_reuse} image-decode reuses. These are local timings, not an accuracy estimate.`;
}
window.nkpiPhase=function(phase){if(!extractionRun||extractionRun.epoch!==state.processEpoch)return;
 const r=extractionRun,now=clock();if(r.phase)r.durations[r.phase]=(r.durations[r.phase]||0)+now-r.phaseStart;r.phase=phase;r.phaseStart=now;timingText();};
window.nkpiBeginExtraction=function(epoch){
 const now=clock();extractionRun={epoch,started:now,phaseStart:now,phase:'startup',durations:{},reviewReady:null,reads:0,studies:0,mapsDone:0,cacheHits:0};
 pipelinePanel().textContent='Step 1 of 2: reading and cross-checking the measurements. Existing verification passes are retained.';
};
window.nkpiRecordRead=function(){if(extractionRun?.epoch===state.processEpoch)extractionRun.reads++;};
window.nkpiMapsRunning=()=>extractionRun?.epoch===state.processEpoch&&extractionRun?.phase==='maps';
window.nkpiMeasurementsReady=function(epoch){if(extractionRun?.epoch!==epoch||epoch!==state.processEpoch)return;
 extractionRun.reviewReady=clock()-extractionRun.started;window.nkpiPhase('maps');
 pipelinePanel().textContent='Measurements ready: review and confirm the numbers now. Step 2 of 2: preparing the associated maps and 3D viewer. Map work does not change the measurements.';
 timingText();syncFrameHeight();};
const uncachedBlobToBitmap=blobToBitmap;
blobToBitmap=async function(blob){
 return decodedReportCache.get(blob,async()=>{
  const bitmap=await uncachedBlobToBitmap(blob);
  try{const canvas=document.createElement('canvas');canvas.width=bitmap.width;canvas.height=bitmap.height;
   canvas.getContext('2d').drawImage(bitmap,0,0);canvas.close=()=>{};return canvas;
  }finally{bitmap.close?.();}
 });
};
window.cancelDeferredReportMaps=function(){
 mapRunSequence++;reportGeneration++;clearTimeout(reportPublishTimer);
 for(const study of [...state.baselineStudies,...state.earlierStudies,...state.laterStudies])
  if(study.mapPreparation==='preparing')study.mapPreparation='pending';
 if(extractionRun?.epoch===state.processEpoch)window.nkpiPhase('measurements');
};
window.startDeferredReportMaps=function(epoch){
 if(epoch!==state.processEpoch)return Promise.resolve();
 const sequence=++mapRunSequence,generation=reportGeneration;
 const studies=(state.mode==='baseline'?state.baselineStudies:[...state.earlierStudies,...state.laterStudies]);
 const pending=studies.filter(s=>s.importDescriptor&&s.mapPreparation!=='ready');
 if(extractionRun?.epoch===epoch){extractionRun.studies=studies.length;window.nkpiPhase('maps');}
 const current=()=>epoch===state.processEpoch&&generation===reportGeneration&&sequence===mapRunSequence;
 const workers=state.workers.filter(w=>!w._nkpiFailed);
 const job=NKPIExtractionFlow.map(pending,workers,epoch,current,async(study,worker)=>{
  study.mapPreparation='preparing';
  try{
   await attachAssociatedReportPages(study.importDescriptor,study,generation,worker);
   NKPIExtractionFlow.check(current);study.mapPreparation='ready';
  }catch(error){
   NKPIExtractionFlow.check(current);study.mapPreparation='failed';
   study.reportMapNotice='Map preparation could not complete. Measurement review remains available; original source pages are retained.';
  }
  if(extractionRun?.epoch===epoch)extractionRun.mapsDone=studies.filter(s=>s.mapPreparation==='ready').length;
  // Do not call renderReview: this would replace input nodes being edited.
  scheduleSourceReportMaps();timingText();
 });
 return job.then(()=>{
  if(!current())return;
  const failed=studies.some(s=>s.mapPreparation==='failed');
  if(extractionRun?.epoch===epoch){window.nkpiPhase('complete');extractionRun.finished=clock();extractionRun.cacheHits+=decodedReportCache.hits;}
  decodedReportCache.clear();
  pipelinePanel().textContent=failed?'Measurements remain ready. Some map preparation failed; check the original source pages.':'Measurements and associated map preparation complete. Verify the measurements against the source before calculating.';
  publishSourceReportMaps();timingText();syncFrameHeight();
 }).catch(error=>{
  if(!current())return;
  if(extractionRun?.epoch===epoch){window.nkpiPhase('error');extractionRun.finished=clock();}
  pipelinePanel().textContent='Map preparation stopped. Your measurement review has been preserved. Re-extract to retry the maps.';timingText();
 });
};
const pipelineReset=resetResultsOnly;
resetResultsOnly=function(){
 mapRunSequence++;extractionRun=null;decodedReportCache.clear();
 const result=pipelineReset();state.processing=false;
 if(el('processButton'))el('processButton').disabled=false;
 hideProgress();el('extractionStages')?.remove();el('extractionTimings')?.remove();
 // Parent scores and maps must not retain a prior source after file/mode change.
 if(typeof invalidateVerifiedPayload==='function')invalidateVerifiedPayload();
 return result;
};
window.addEventListener('pagehide',()=>{mapRunSequence++;decodedReportCache.clear();});
window.NKPIExtractionMetrics=Object.freeze({snapshot:pipelineMetrics});
