'use strict';
// Exercise the actual browser controller's identity binding. Rendering is stubbed
// solely to inspect selection eligibility without WebGL or patient source data.
const assert=require('node:assert/strict'),fs=require('fs'),vm=require('vm');
let source=fs.readFileSync(require('node:path').join(__dirname,'../components/regional_change.js'),'utf8');
const tail="render();\n})(typeof window!=='undefined'?window:globalThis);";
assert(source.endsWith(tail+'\n')||source.endsWith(tail));
source=source.replace(tail,"render=function(){}; root.__bound=boundShapeSets; render();\n})(typeof window!=='undefined'?window:globalThis);");
const c={console,location:{origin:'https://fixture.invalid'},URL,document:{getElementById(){return {addEventListener(){}};}},NKPI:{stable:JSON.stringify,canonical:x=>x}};c.window=c;c.globalThis=c;vm.createContext(c);vm.runInContext(source,c);
const caseOD={enabled:true,eye:'OD',mode:'baseline',age:30,first:{A:7.2}};
const reports=[{eye:'OD',visit:'first',source_id:'same-import-study',pages:[{id:'page-1',url:'blob:https://fixture.invalid/first'}]}];
c.NKPIRegional.setReports(reports);c.NKPIRegional.bindImported({OD:caseOD});c.NKPIRegional.setContext({cases:{OD:caseOD},results:{OD:{case:caseOD}},sourceDirty:false});
assert.equal(c.__bound('OD').length,1);
c.NKPIRegional.setReports([{...reports[0],pages:[...reports[0].pages,{id:'page-2',url:'blob:https://fixture.invalid/late'}]}]);assert.equal(c.__bound('OD').length,1);
c.NKPIRegional.setReports([{...reports[0],source_id:'different-study'}]);assert.equal(c.__bound('OD').length,0);
c.NKPIRegional.setReports(reports);c.NKPIRegional.setContext({cases:{OD:{...caseOD,age:31}},results:{OD:{case:caseOD}},sourceDirty:false});assert.equal(c.__bound('OD').length,0);
c.NKPIRegional.setContext({cases:{OD:caseOD},results:{OD:{case:caseOD}},sourceDirty:true});assert.equal(c.__bound('OD').length,0);
console.log('PASS same-source late map enrichment stays bound; changed source, changed numeric inputs and dirty state remain unbound.');
