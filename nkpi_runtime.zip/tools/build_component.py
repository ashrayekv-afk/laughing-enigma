"""Rebuild the self-contained component HTML after editing its JS or CSS."""
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1] / "components"
text = (root / "index.template.html").read_text(encoding="utf-8")
def local_path(name):
    path = (root / name.split("?", 1)[0]).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("Asset path outside component directory")
    return path

def style(match):
    name = match[1].split("?", 1)[0]
    content = local_path(name).read_text(encoding="utf-8")
    if "</style" in content.lower():
        raise ValueError("Unexpected closing style tag")
    return '<style data-nkpi-source="' + name + '">\n' + content + '\n</style>'

def script(match):
    name = match[1].split("?", 1)[0]
    content = local_path(name).read_text(encoding="utf-8")
    content = re.sub('</script', r'<\\/script', content, flags=re.I)
    return '<script data-nkpi-source="' + name + '">\n' + content + '\n</script>'

text = re.sub(r'<link rel="stylesheet" href="([^"]+)">', style, text)
text = re.sub(r'<script src="([^"]+)"></script>', script, text)
(root / "index.html").write_text(text, encoding="utf-8")
print("Built self-contained component index.html")
